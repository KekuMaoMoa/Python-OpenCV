import cv2
import numpy as np

def optimized_threshold_segmentation(image_path, blur_kernel_size=(5, 5), block_size=11, constant=2):
    """
    使用自适应阈值分割算法对图像进行分割。

    参数:
    - image_path: 输入图像的路径
    - blur_kernel_size: 高斯模糊的核大小，默认为(5, 5)
    - block_size: 自适应阈值的邻域大小，必须为奇数，默认为11
    - constant: 从计算的平均值或加权平均值中减去的常数，默认为2

    返回:
    - thresh: 分割后的二值图像
    """
    # 读取图像并转换为灰度
    image = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
    
    # 高斯模糊以减少噪声
    blurred = cv2.GaussianBlur(image, blur_kernel_size, 0)
    
    # 应用自适应阈值
    thresh = cv2.adaptiveThreshold(blurred, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, 
                                   cv2.THRESH_BINARY, block_size, constant)
    
    return thresh

if __name__ == "__main__":
    # 图像路径
    image_path = r"C:\Users\Administrator\Desktop\Hello.png"
    
    # 调用优化阈值分割函数
    segmented_image = optimized_threshold_segmentation(image_path)
    
    
    # 如果需要显示图像，可以取消以下注释
    cv2.imshow('Optimized Threshold Segmentation', segmented_image)
    cv2.waitKey(0)
    cv2.destroyAllWindows()