import cv2

def canny_edge_detection(image_path, blur_kernel_size=(5, 5), canny_threshold1=50, canny_threshold2=150):
    """
    使用Canny边缘检测算法检测图像中的边缘。

    参数:
    - image_path: 输入图像的路径
    - blur_kernel_size: 高斯模糊的核大小，默认为(5, 5)
    - canny_threshold1: Canny算法的第一个阈值，默认为50
    - canny_threshold2: Canny算法的第二个阈值，默认为150

    返回:
    - edges: 检测到的边缘图像
    """
    # 读取图像并转换为灰度
    image = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
    
    # 高斯模糊以减少噪声
    blurred = cv2.GaussianBlur(image, blur_kernel_size, 0)
    
    # 使用Canny边缘检测
    edges = cv2.Canny(blurred, canny_threshold1, canny_threshold2)
    
    return edges

def display_image(window_name, image):
    """
    显示图像。

    参数:
    - window_name: 窗口名称
    - image: 要显示的图像
    """
    cv2.imshow(window_name, image)
    cv2.waitKey(0)
    cv2.destroyAllWindows()

