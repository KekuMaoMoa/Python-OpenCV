import cv2
import numpy as np

def load_image(image_path):
    """加载图像，支持中文路径"""
    image = cv2.imdecode(np.fromfile(image_path, dtype=np.uint8), cv2.IMREAD_COLOR)
    return image

def preprocess_image(image):
    """图像预处理：灰度化、高斯模糊"""
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    gray_blur = cv2.GaussianBlur(gray, (3, 3), 0)
    return gray_blur

def compute_gradients(gray_blur):
    """计算Sobel梯度"""
    sobelx = cv2.Sobel(gray_blur, cv2.CV_64F, 1, 0, ksize=3)
    sobely = cv2.Sobel(gray_blur, cv2.CV_64F, 0, 1, ksize=3)
    return sobelx, sobely

def filter_horizontal_edges(sobelx, sobely, angle_threshold=10):
    """过滤水平边缘"""
    magnitude, angle = cv2.cartToPolar(sobelx, sobely, angleInDegrees=True)
    angle_mod = angle % 180
    mask = ((angle_mod < (90 - angle_threshold)) | (angle_mod > (90 + angle_threshold))).astype(np.uint8) * 255
    return mask

def detect_edges(gray_blur, low_threshold=40, high_threshold=50):
    """Canny边缘检测"""
    edges = cv2.Canny(gray_blur, low_threshold, high_threshold)
    return edges

def apply_mask(edges, mask):
    """应用掩膜过滤边缘"""
    filtered_edges = cv2.bitwise_and(edges, mask)
    return filtered_edges

def denoise_morphology(filtered_edges, kernel_size=(1, 1)):
    """形态学去噪"""
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, kernel_size)
    filtered_edges = cv2.morphologyEx(filtered_edges, cv2.MORPH_OPEN, kernel)
    return filtered_edges

def filter_connected_components(filtered_edges, min_area=40):
    """连通区域过滤"""
    num_labels, labels, stats, _ = cv2.connectedComponentsWithStats(filtered_edges)
    result = np.zeros_like(filtered_edges)
    for i in range(1, num_labels):
        if stats[i, cv2.CC_STAT_AREA] >= min_area:
            result[labels == i] = 255
    return result

def display_and_save_results(image, result, save_path='Optimized_Result.jpg'):
    """显示并保存结果"""
    result = cv2.cvtColor(result, cv2.COLOR_GRAY2BGR)
    h, w = image.shape[:2]
    result = cv2.resize(result, (w, h))

    combined = np.hstack((image, result))
    return combined

def crack_inspection_main(image_path):
    """主函数"""
    image = load_image(image_path)
    gray_blur = preprocess_image(image)
    sobelx, sobely = compute_gradients(gray_blur)
    mask = filter_horizontal_edges(sobelx, sobely)
    edges = detect_edges(gray_blur)
    filtered_edges = apply_mask(edges, mask)
    filtered_edges = denoise_morphology(filtered_edges)
    result = filter_connected_components(filtered_edges)
    return display_and_save_results(image, result)
     
