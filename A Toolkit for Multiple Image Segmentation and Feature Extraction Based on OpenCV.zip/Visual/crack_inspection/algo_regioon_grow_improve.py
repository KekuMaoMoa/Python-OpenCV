import cv2
import numpy as np
from collections import deque


ALGO_NAME = "优化的区域生长分割检测"

def process(image):
    """
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

    # 定义种子点
    seed_point = (100, 100)  # 根据需要调整
    new_val = 255
    old_val = gray[seed_point]  # 使用灰度图像的值

    # 创建掩码
    mask = np.zeros_like(gray, dtype=np.uint8)
    mask[seed_point] = 255

    # 区域生长
    height, width = gray.shape
    for y in range(height):
        for x in range(width):
            if mask[y, x] == 255:
                continue
            if abs(int(gray[y, x]) - int(old_val)) < 10:  # 阈值
                mask[y, x] = 255

    return mask
    """





    # 转换为灰度图像
    if len(image.shape) == 3:
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    else:
        gray = image.copy()

    # 高斯模糊
    blurred = cv2.GaussianBlur(gray, (5, 5), 0)

    # 定义种子点
    seed_point = (100, 100)  # 需要确保在图像范围内
    
    # 验证种子点有效性
    if (seed_point[0] >= blurred.shape[0] or 
        seed_point[1] >= blurred.shape[1]):
        raise ValueError("Seed point out of image bounds")

    # 初始化掩码
    mask = np.zeros_like(blurred, dtype=np.uint8)
    old_val = blurred[seed_point]

    # 使用队列实现BFS算法
    queue = deque()
    queue.append(seed_point)
    mask[seed_point] = 255

    # 定义8邻域
    directions = [(-1, -1), (-1, 0), (-1, 1),
                  (0, -1),          (0, 1),
                  (1, -1),  (1, 0), (1, 1)]

    # 区域生长参数
    threshold = 10  # 灰度差异阈值

    while queue:
        current_point = queue.popleft()
        
        for d in directions:
            y = current_point[0] + d[0]
            x = current_point[1] + d[1]

            # 边界检查
            if (0 <= y < blurred.shape[0] and 
                0 <= x < blurred.shape[1] and 
                mask[y, x] == 0):
                
                # 灰度值差异检查
                if abs(int(blurred[y, x]) - int(old_val)) < threshold:
                    mask[y, x] = 255
                    queue.append((y, x))

    return mask