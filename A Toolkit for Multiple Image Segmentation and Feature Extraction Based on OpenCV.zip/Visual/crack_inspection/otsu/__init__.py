# 文件名: image_segmentation.py

from skimage import io, filters, measure, morphology
import matplotlib.pyplot as plt

class ImageSegmentation:
    def __init__(self, image_path):
        self.image_path = image_path
        self.image = None
        self.blurred = None
        self.binary = None
        self.label_image = None
        self.cleaned = None

    def load_image(self):
        """加载图像并将其转换为灰度图像"""
        self.image = io.imread(self.image_path, as_gray=True)

    def apply_gaussian_blur(self, sigma=1):
        """应用高斯模糊以减少噪声"""
        self.blurred = filters.gaussian(self.image, sigma=sigma)

    def apply_otsu_threshold(self):
        """应用Otsu阈值分割"""
        thresh = filters.threshold_otsu(self.blurred)
        self.binary = self.blurred > thresh

    def label_regions(self):
        """对二值图像进行标签处理"""
        self.label_image = measure.label(self.binary)

    def remove_small_objects(self, min_size=500):
        """去除小区域"""
        self.cleaned = morphology.remove_small_objects(self.label_image, min_size=min_size)

    def show_result(self):
        """显示分割结果"""
        plt.imshow(self.cleaned, cmap='gray')
        plt.title('Optimized Scikit-image Segmentation')
        plt.axis('off')
        plt.show()

    def process_image(self, sigma=1, min_size=500):
        """处理图像的完整流程"""
        self.load_image()
        self.apply_gaussian_blur(sigma)
        self.apply_otsu_threshold()
        self.label_regions()
        self.remove_small_objects(min_size)
        self.show_result()

image_path = r"C:\Users\Administrator\Desktop\Hello.png"
segmenter = ImageSegmentation(image_path)
segmenter.process_image(sigma=1, min_size=500)